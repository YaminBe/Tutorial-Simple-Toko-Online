<?php 
$db_host = "localhost"; // untuk server lokal kita
$db_user = "root"; // untuk usernme database .. disini masih default " root"
$db_pass =""; // untuk ppasswor database. disesuikan jika db mempunyai password
$db_name ="db_aqilla"; // nama database kita yaitu : db_aqilla

$koneksi = mysqli_connect($db_host,$db_user,$db_pass,$db_name);

if (mysqli_connect_error()) {
	// Tampilkan pesan 
	echo ' Gagal melakukan koneksi ke Database :'.mysqli_connect_error();
	
}

 ?>